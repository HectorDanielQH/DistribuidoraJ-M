@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>DISTRIBUIDORA H&J</h1>
@stop

@section('content')
    <div class="container">
        
    </div>
@stop

@section('css')

@stop

@section('js')
    <script src="https://code.jquery.com/jquery-3.7.1.slim.min.js" integrity="sha256-kmHvs0B+OpCW5GVHUNjv9rOmY0IvSIRcf7zGUDTDQM8=" crossorigin="anonymous"></script>
@stop
