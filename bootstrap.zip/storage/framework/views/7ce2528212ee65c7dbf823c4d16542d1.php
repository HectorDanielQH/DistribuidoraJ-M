<aside class="control-sidebar control-sidebar-<?php echo e(config('adminlte.right_sidebar_theme')); ?>">
    <?php echo $__env->yieldContent('right_sidebar'); ?>
</aside>
<?php /**PATH C:\MAMP\htdocs\DistribuidoraProyecto\resources\views/vendor/adminlte/partials/sidebar/right-sidebar.blade.php ENDPATH**/ ?>