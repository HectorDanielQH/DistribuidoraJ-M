<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MIS RUTAS</title>

    <link rel="stylesheet" href="<?php echo e(public_path('css/bootstrap.min.css')); ?>">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        .logo {
            width: 150px;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <img src="<?php echo e(public_path('images/logo_distribuidora.jpg')); ?>" alt="Logo" class="logo">
    </div>
    <div class="container">
        <h1 class="text-center text-black">Mis Rutas</h1>
        <table>
            <tr>
                <td><small>Preventista:</small></td>
                <td><small><?php echo e($usuario->nombres); ?> <?php echo e($usuario->apellido_materno); ?> <?php echo e($usuario->apellido_paterno); ?></small></td>
            </tr>
            <tr>
                <td><small>Fecha:</small></td>
                <td><small><?php echo e(now()); ?></small></td>
            </tr>
        </table>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Ruta</th>
                    <th>Dirección</th>
                    <th>Cliente</th>
                    <th>Celular</th>
                    <th>Fecha de Asignacion</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($asignacion->ruta->nombre_ruta); ?></td>
                        <td><?php echo e($asignacion->ubicacion); ?></td>
                        <td><?php echo e($asignacion->nombres); ?> <?php echo e($asignacion->apellido_paterno); ?> <?php echo e($asignacion->apellido_materno); ?></td>
                        <td><?php echo e($asignacion->celular); ?></td>
                        <td><?php echo e($asignacion->asignacion_fecha_hora); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\DistribuidoraProyecto\resources\views/vendedor/pdf/pedidos_pdf_rutas.blade.php ENDPATH**/ ?>